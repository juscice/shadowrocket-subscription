/********************************
MGW Remove Ads - Version 1.0
Inluding - ABC, eCNY, boscLife, 12306
Please note that you may need to reinstall app for script to work.

QuantumultX rewrite link:
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/QuanX/Adblock/App/0-9/12306/rewrite/12306.conf
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/QuanX/Adblock/App/S/上海银行/rewrite/bosc.conf
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/QuanX/Adblock/App/S/上银美好生活/rewrite/bosclife.conf
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/QuanX/Adblock/App/S/数字人民币/rewrite/ecny.conf
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/QuanX/Adblock/App/Z/中国农业银行/rewrite/abc.conf
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/QuanX/Adblock/App/Z/招商永隆银行/rewrite/cmbwl.conf

Surge module link:
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/Surge/Adblock/App/0-9/12306/12306.sgmodule
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/Surge/Adblock/App/S/上海银行/bosc.sgmodule
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/Surge/Adblock/App/S/上银美好生活/bosclife.sgmodule
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/Surge/Adblock/App/S/数字人民币/ecny.sgmodule
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/Surge/Adblock/App/Z/中国农业银行/abc.sgmodule
https://raw.githubusercontent.com/zirawell/R-Store/main/Rule/Surge/Adblock/App/Z/招商永隆银行/cmbwl.sgmodule
********************************/

const url = $request.url;
const header = $request.headers;
const headopt = header["Operation-Type"] || header["operation-type"];

const generalBlockList = [
  "alipay.client.updateVersion",
  "alipay.client.getUnionResource"
];

const blockListFor12306 = [
  //"com.cars.otsmobile.integration.activityBanner",            // 活动横幅
  "com.cars.otsmobile.memberInfo.getMemberQa",                  // 铁路会员 常见问题
  // "com.cars.otsmobile.memberInfo.integrationHomeInit",       // 铁路会员 会员信息
  // "com.cars.otsmobile.newHomePage.getWeatherByStationCode",  // 天气信息
  "com.cars.otsmobile.newHomePage.initData",                    // 热门资讯
  "com.cars.otsmobile.newHomePageBussData"                      // 商品信息流
];

const blockListForBosc = [
  "api.public.marketing.popup",
  "api.public.journey.popup",
  "api.public.popupWindow.navigationPup",
  "api.topicComponent.topicInfoQry",
  "api.waterfall.newsContentInfoQry",
  "api.public.getUrl.mobileStart",
  "api.public.versionUpdate.Android",
  "api.public.loginController.grayReleasQuery"
];

const blockListForBoscLife = [
  "com.GLMobile.Market.PopupListQry",
  "com.GLMobile.Customer.QryGreeting",
  "com.GLMobile.Market.SecondFloorResourcesQry",
  "com.GLMobile.NewOnlineService.HomeData",
  "com.GLMobile.Customer.HomePageInfoQry"
];

const blockListForECNY = [
    "com.dcep.walletapp.api.securityEnvDetect"
];

const blockListForABC = [
  "com.bankabc.recommendcenter.homepage.gethpadverinfo",
  "com.abchina.mbank.common.homepage.getStartParam",
  "com.abchina.mbank.common.homepage.getIOSDownLoadInfo",
  "com.bankabc.credit.welfareCenter.getadverinfo",
  //"com.bankabc.credit.home.getCcocAdInfo",
  "com.bankabc.credit.query.custbillqry.getadv",
  "com.abchina.mbank.securitycenter.msmp.antiHijack"
];

const blockListForCmbwl = [
  "com.wlbbank.mb0003.rdpHomePagePopUp",
  "com.wlbbank.mb0003.HomePageStarterZone",
  "com.wlbbank.ifcms.GetGategoryInformationList",
  "com.wlbbank.notice.getWaterNotify",
  "com.wlbbank.appfloatwindow.queryappfloatwindow"
];

const isGeneralBlock = generalBlockList.includes(headopt);
const isAbcBlock = url.includes("mobilepaas.abchina.com") && blockListForABC.includes(headopt);
const isECNYBlock = url.includes("mgs.wallet.pbcdci.cn") && blockListForECNY.includes(headopt);
const isBoscLifeBlock = url.includes("mgs1.bosc.cn") && blockListForBoscLife.includes(headopt);
const isBoscBlock = url.includes("pmbservice.bosc.cn") && blockListForBosc.includes(headopt);
const is12306Block = url.includes("mobile.12306.cn") && blockListFor12306.includes(headopt);
const isCmbwlBlock = url.includes("cmbwinglungbank.com") && blockListForCmbwl.includes(headopt);

if (isGeneralBlock || isAbcBlock || isECNYBlock || isBoscLifeBlock || isBoscBlock || is12306Block || isCmbwlBlock) {
  $done({status: "HTTP/1.1 204 No Content", body: "", headers: ""});   
} else {
  $done({});
}
